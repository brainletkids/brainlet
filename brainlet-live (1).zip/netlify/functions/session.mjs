import { check } from '../lib/token.mjs';
import { getLearner } from '../lib/store.mjs';
import { json, readJson, isPhone } from '../lib/http.mjs';

export default async (req) => {
  if (req.method !== 'POST') return json(405, { ok: false });
  const body = await readJson(req);
  try {
    const phone = check(body && body.token);
    if (!isPhone(phone)) return json(200, { ok: false, reason: 'expired' });
    let profile = null;
    try {
      const rec = await getLearner(phone);
      if (rec && rec.name) profile = { name: rec.name, age: rec.age, level: rec.level };
    } catch (e) {
      console.log('Storage problem:', e && e.message);
    }
    return json(200, { ok: true, phone, profile });
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};

export const config = { path: '/api/session' };

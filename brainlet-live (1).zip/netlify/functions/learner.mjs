import { check } from '../lib/token.mjs';
import { getLearner, putLearner } from '../lib/store.mjs';
import { notify, fmtPhone, fmtTime } from '../lib/mail.mjs';
import { json, readJson, isPhone } from '../lib/http.mjs';

const LEVELS = ['Not started yet', 'Level 1', 'Level 2', 'Level 3', 'Level 4', 'Level 5', 'Level 6', 'Level 7', 'Level 8'];
const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M} .'’-]{1,39}$/u;

export default async (req) => {
  if (req.method !== 'POST') return json(405, { ok: false });
  const body = await readJson(req);
  if (!body) return json(400, { ok: false, reason: 'invalid' });

  let phone;
  try { phone = check(body.token); } catch (e) { return json(502, { ok: false, reason: 'server' }); }
  if (!isPhone(phone)) return json(401, { ok: false, reason: 'auth' });

  const name = String(body.name || '').trim().replace(/\s+/g, ' ');
  const age = Number(body.age);
  const level = String(body.level || '');
  if (!NAME_RE.test(name) || !Number.isInteger(age) || age < 2 || age > 18 || !LEVELS.includes(level)) {
    return json(400, { ok: false, reason: 'invalid' });
  }

  try {
    const now = new Date().toISOString();
    const rec = (await getLearner(phone)) || { phone, createdAt: now, lastLogin: now, logins: 1 };
    const first = !rec.name;
    rec.name = name;
    rec.age = age;
    rec.level = level;
    rec.detailsAt = now;
    await putLearner(rec);
    await notify(
      `Brainlet: ${first ? 'new learner' : 'learner updated'} ${name} (${fmtPhone(phone)})`,
      `${first ? 'New learner details' : 'Learner details were updated'} on Brainlet.\n\nChild's name: ${name}\nAge: ${age}\nLevel: ${level}\nMobile: ${fmtPhone(phone)}\nTime: ${fmtTime(now)}`
    );
    return json(200, { ok: true, profile: { name, age, level } });
  } catch (e) {
    console.log('Storage problem:', e && e.message);
    return json(502, { ok: false, reason: 'server' });
  }
};

export const config = { path: '/api/learner' };

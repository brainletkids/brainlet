import { check } from '../lib/token.mjs';
import { listLearners } from '../lib/store.mjs';
import { json, readJson } from '../lib/http.mjs';

export default async (req) => {
  if (req.method !== 'POST') return json(405, { ok: false });
  const body = await readJson(req);
  let who;
  try { who = check(body && body.token); } catch (e) { return json(502, { ok: false, reason: 'server' }); }
  if (who !== 'admin') return json(401, { ok: false, reason: 'auth' });
  try {
    const learners = await listLearners();
    learners.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json(200, { ok: true, learners });
  } catch (e) {
    console.log('Storage problem:', e && e.message);
    return json(502, { ok: false, reason: 'server' });
  }
};

export const config = { path: '/api/admin/learners' };

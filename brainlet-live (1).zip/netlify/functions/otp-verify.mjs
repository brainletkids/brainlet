import { checkVerification } from '../lib/twilio.mjs';
import { sign } from '../lib/token.mjs';
import { getLearner, putLearner } from '../lib/store.mjs';
import { notify, fmtPhone, fmtTime } from '../lib/mail.mjs';
import { json, readJson, isPhone } from '../lib/http.mjs';

export default async (req) => {
  if (req.method !== 'POST') return json(405, { ok: false });
  const body = await readJson(req);
  const phone = String((body && body.phone) || '');
  const code = String((body && body.code) || '');
  if (!isPhone(phone) || !/^\d{6}$/.test(code)) return json(400, { ok: false, reason: 'wrong' });

  try {
    const r = await checkVerification(phone, code);
    if (!r.ok) return json(r.reason === 'locked' ? 429 : r.reason === 'server' ? 502 : 200, r);

    // The code is right. Record the number and tell the owner about new ones.
    // A storage problem must never stop a learner from logging in.
    let profile = null;
    try {
      const now = new Date().toISOString();
      let rec = await getLearner(phone);
      if (rec) {
        rec.lastLogin = now;
        rec.logins = (rec.logins || 0) + 1;
        await putLearner(rec);
      } else {
        rec = { phone, name: null, age: null, level: null, createdAt: now, lastLogin: now, logins: 1 };
        await putLearner(rec);
        await notify(
          `Brainlet: new mobile number ${fmtPhone(phone)}`,
          `A new mobile number has verified its login on Brainlet.\n\nMobile: ${fmtPhone(phone)}\nTime: ${fmtTime(now)}\n\nThe learner details (name, age, level) will follow in a second email once they are filled in.`
        );
      }
      if (rec.name) profile = { name: rec.name, age: rec.age, level: rec.level };
    } catch (e) {
      console.log('Storage problem:', e && e.message);
    }
    return json(200, { ok: true, token: sign(phone, 30), profile });
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};

export const config = { path: '/api/otp/verify' };

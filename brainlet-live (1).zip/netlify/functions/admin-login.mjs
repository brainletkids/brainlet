import crypto from 'node:crypto';
import { sign } from '../lib/token.mjs';
import { json, readJson } from '../lib/http.mjs';

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();

export default async (req) => {
  if (req.method !== 'POST') return json(405, { ok: false });
  const body = await readJson(req);
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected || expected.length < 8) return json(503, { ok: false, reason: 'server' });

  const good = body && crypto.timingSafeEqual(sha(body.password || ''), sha(expected));
  if (!good) {
    await new Promise((r) => setTimeout(r, 1000)); // slows down password guessing
    return json(401, { ok: false, reason: 'auth' });
  }
  try {
    return json(200, { ok: true, token: sign('admin', 0.5) }); // valid for 12 hours
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};

export const config = { path: '/api/admin/login' };

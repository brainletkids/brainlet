import { startVerification } from '../lib/twilio.mjs';
import { json, readJson, isPhone } from '../lib/http.mjs';

export default async (req) => {
  if (req.method !== 'POST') return json(405, { ok: false });
  const body = await readJson(req);
  if (!body || !isPhone(String(body.phone || ''))) return json(400, { ok: false, reason: 'invalid' });
  try {
    const r = await startVerification(String(body.phone));
    const status = r.ok ? 200 : r.reason === 'ratelimit' ? 429 : r.reason === 'invalid' ? 400 : 502;
    return json(status, r);
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};

export const config = { path: '/api/otp/send' };

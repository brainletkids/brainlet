# Brainlet site

Learners log in with a mobile number and an SMS code, then enter their child's name, age and level. Every new number is emailed to you, and you can see everyone on a password-protected dashboard.

```
public/index.html            the learner website
public/admin/index.html      your dashboard, at yoursite.netlify.app/admin/
netlify/functions/*.mjs      the server functions (send OTP, verify OTP, save learner, admin)
netlify/lib/*.mjs            SMS (Twilio), email (Resend), storage (Netlify Blobs), signed tokens
netlify.toml, package.json   Netlify settings
```

## What you will set up (three free accounts)

### 1. Twilio Verify, for the SMS code
1. Create an account at twilio.com. In the Console go to Verify, then Services, and create a service named "Brainlet". Copy its **Service SID** (starts with `VA`).
2. From the Console home page copy your **Account SID** (starts with `AC`) and **Auth Token**.
3. A trial account only texts numbers you have verified yourself. Upgrade before sharing the site.
4. Check Twilio's current prices and rules for SMS to India. Every login sends one SMS.

### 2. Resend, for the emails to you
1. Create a free account at resend.com **using the email address where you want to receive the numbers**.
2. Open API Keys and create a key. Copy it (starts with `re_`).
3. Without your own domain, Resend can only send to the email you signed up with. That is exactly what you need here. Later you can verify a domain in Resend and set `MAIL_FROM`.

### 3. Netlify, for hosting
1. Create a free GitHub account and a repository, for example `brainlet`. Upload everything from this folder, keeping the structure.
2. In Netlify choose **Add new site**, then **Import an existing project**, and pick the repository. Leave the build command empty.
3. Under **Site configuration**, then **Environment variables**, add these:

| Name | Value |
| --- | --- |
| `TWILIO_ACCOUNT_SID` | your Twilio Account SID |
| `TWILIO_AUTH_TOKEN` | your Twilio Auth Token |
| `TWILIO_VERIFY_SERVICE_SID` | your Verify Service SID |
| `RESEND_API_KEY` | your Resend API key |
| `ADMIN_EMAIL` | the email address that should receive the numbers |
| `ADMIN_PASSWORD` | a password for the dashboard, 8 or more characters |
| `SESSION_SECRET` | a long random string, 32 or more characters |
| `MAIL_FROM` | optional, for example `Brainlet <hello@yourdomain.com>` once your domain is verified in Resend |

4. Deploy. Under **Site configuration**, then **Change site name**, choose `brainlet`.
5. Netlify Blobs, where the learners are stored, needs no setup.

Keep the Twilio token, the Resend key and the passwords private. Never paste them into a web page.

## Using it

- **Learners:** open the site, log in with their mobile number and the SMS code, then fill in the child's name, age and level. Returning learners go straight in. They can change the details with "Edit learner details".
- **Emails to you:** one email when a new number verifies, and one when the child's details are saved or changed.
- **Dashboard:** open `yoursite.netlify.app/admin/` and log in with `ADMIN_PASSWORD`. You see totals, learners by level and age, new numbers per day, and a searchable table. Use **Export CSV** to download a spreadsheet, or **Copy numbers** to copy the mobile numbers.

## Test before you share

1. Open the site and log in with your own number. Check that the SMS arrives, the child form appears, and an email reaches you.
2. Open `/admin/` and check that you appear in the table.
3. Log out, log in again, and check that the child's details are remembered.

## Good to know

- One child is stored per mobile number. A second child on the same number would replace the first. Tell me if you need several children per number.
- The dashboard reads every record on each load. That is fine for hundreds or a few thousand learners. For more, the storage should move to a proper database.
- The worksheet generator runs in the visitor's browser. The login proves a phone number, but it does not stop a technical user from reading the page source.
- This site collects children's personal data. Add a privacy policy and a clear consent line, and read up on India's data protection rules for children's data before launch. A lawyer can confirm what applies to you.
- To use MSG91 or another SMS provider, change only `netlify/lib/twilio.mjs`.
- To try it on your computer: install Node.js, run `npm install` and then `npx netlify dev` in this folder, and put the same variables in a `.env` file.

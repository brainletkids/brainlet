# Brainlet site (live OTP login)

```
public/index.html            the website
netlify/functions/*.js       three small server functions (send OTP, verify OTP, check session)
netlify/lib/twilio.js        the SMS provider (Twilio Verify)
netlify/lib/token.js         signed login tokens
netlify.toml                 routes /api/... to the functions
```

## 1. Set up SMS (Twilio Verify)

1. Create an account at twilio.com and open the Console.
2. Go to Verify, then Services, and create a service named "Brainlet". Copy its **Service SID** (starts with `VA`).
3. From the Console home page copy your **Account SID** (starts with `AC`) and **Auth Token**.
4. A trial account can only text numbers you have verified in Twilio. Upgrade the account before sharing the site publicly.
5. Check Twilio's current rules and prices for SMS to India before launch. Indian operators have registration requirements, and the per-message cost applies to every login.

## 2. Deploy on Netlify (free plan)

Functions need a Git or CLI deploy, not the drag-and-drop page.

1. Create a free GitHub account and a new repository, for example `brainlet`.
2. Upload everything in this folder to it, keeping the folder structure.
3. In Netlify choose **Add new site**, then **Import an existing project**, and pick the repository. Leave the build command empty. The publish folder is read from `netlify.toml`.
4. Before the first deploy, open **Site configuration**, then **Environment variables**, and add:

| Name | Value |
| --- | --- |
| `TWILIO_ACCOUNT_SID` | your Account SID |
| `TWILIO_AUTH_TOKEN` | your Auth Token |
| `TWILIO_VERIFY_SERVICE_SID` | your Verify Service SID |
| `SESSION_SECRET` | a long random string, 32 or more characters |

5. Deploy. Then change the site name to `brainlet` under **Site configuration**, then **Change site name**.

Keep the Auth Token and `SESSION_SECRET` private. Never paste them into `index.html`.

## 3. Test

Open the site, enter your own mobile number, and check that the SMS arrives and that the code opens the worksheet tools. Log out and log in again.

## Notes

- Twilio Verify creates the codes, expires them after 10 minutes and limits wrong attempts. The site adds a 30-second resend wait and a signed login token that lasts 30 days.
- The worksheet generator itself runs in the visitor's browser. The login proves a phone number, but it does not stop a technical user from reading the page source. If worksheets must be truly private, move the generator into a function that checks the token.
- To use MSG91 or another provider, change only `netlify/lib/twilio.js`.
- To try it on your computer: install Node.js, run `npx netlify dev` in this folder, and set the same four variables in a `.env` file.

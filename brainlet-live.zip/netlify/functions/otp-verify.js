const { checkVerification } = require('../lib/twilio');
const { sign } = require('../lib/token');

const SESSION_DAYS = 30;
const json = (status, body) => ({
  statusCode: status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false });
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false, reason: 'wrong' }); }
  const phone = String(body.phone || '');
  const code = String(body.code || '');
  if (!/^\d{8,15}$/.test(phone) || !/^\d{6}$/.test(code)) return json(400, { ok: false, reason: 'wrong' });
  try {
    const r = await checkVerification(phone, code);
    if (!r.ok) return json(r.reason === 'locked' ? 429 : r.reason === 'server' ? 502 : 200, r);
    return json(200, { ok: true, token: sign(phone, SESSION_DAYS) });
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};

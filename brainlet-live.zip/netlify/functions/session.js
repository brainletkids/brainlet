const { check } = require('../lib/token');

const json = (status, body) => ({
  statusCode: status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false });
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false }); }
  try {
    const phone = check(body.token);
    return phone ? json(200, { ok: true, phone }) : json(200, { ok: false, reason: 'expired' });
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};

const { startVerification } = require('../lib/twilio');

const json = (status, body) => ({
  statusCode: status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false });
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false, reason: 'invalid' }); }
  const phone = String(body.phone || '');
  if (!/^\d{8,15}$/.test(phone)) return json(400, { ok: false, reason: 'invalid' });
  try {
    const r = await startVerification(phone);
    const status = r.ok ? 200 : r.reason === 'ratelimit' ? 429 : r.reason === 'invalid' ? 400 : 502;
    return json(status, r);
  } catch (e) {
    return json(502, { ok: false, reason: 'server' });
  }
};
